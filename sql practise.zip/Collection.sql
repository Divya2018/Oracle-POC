/*1. Varrays - arrays, size fixed, index start with 1,  cannot delete elements
2. Nested table - list, size variable, index start with 1
3. Associated array / Index by table - Map/HashMap, Index by strings, Record + nested table
*/

--Varrays
set serveroutput on;
declare
type my_varray IS varray(5) of number;
emp_id my_varray;
i number :=1;
c constant number :=3;
begin 
    select employeeId bulk collect into emp_id from employee;
    while(i<=c)
    LOOP
        DBMS_OUTPUT.PUT_LINE(emp_id(i));
        i := i+1;
    end loop;
    exception
        when no_data_found then
            dbms_output.put_line('No result set data');
    end;
end;

-- nested table
declare
type nested_tab IS TABLE of number;
type ids IS TABLE of employee.employeeid.%TYPE;
my_nest_tab ids;
begin
loop
    DBMS_OUTPUT.PUT_LINE(ids);
end loop;
end;

-- associated array/ index of table
declare
    type emp_rec IS RECORD(
    eid employeeId%TYPE,
    ename firstName%TYPE
    );
    Type my_nested_table IS TABLE of emp_rec;
    my_asso_arr my_nested_table;
