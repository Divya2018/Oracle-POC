
CREATE TABLE Person (
  id number(11) NOT NULL,
  name varchar2(20) NOT NULL,
  country varchar2(20),
  PRIMARY KEY (id)
);

create view person_view as 
select p.id, p.name from person p where p.country='india';

create or replace trigger update_name_view_trigger
instead of update on person_view
begin
update person set 
name = substr(:new.name, instr(:new.name, ',')+2) where id = :old.id;
end;


create sequence person_sequence increment by 1 start with 1 order;

create or replace trigger person_on_insert
before insert on person
for each row
begin
    select person_sequence.nextval 
    into :new.id 
    from dual;
end;

create table Person_log(
log_date DATE, action varchar2(50)
);

create trigger person_change_trigger
after insert or update or delete on person
declare log_action Person_log.action%TYPE;
begin
if inserting then 
    log_action := 'Insert';
elsif updating then 
    log_action := 'Update';
elsif deleting then 
    log_action := 'Delete';
else 
dbms_output.put_line('This code is not reachable');
end if;
insert into Person_log values (SYSDATE, log_action);
end;

SELECT * FROM USER_ERRORS WHERE TYPE = 'TRIGGER';

select * from Person;
select * from person_view;
select * from Person_log;

insert into Person values(person_sequence.nextval,'Divya','India');
insert into Person values(person_sequence.nextval,'Kavi','India');

select person_sequence.nextval from dual;

describe person;

commit;

delete from person;

drop trigger person_on_insert;
DROP TRIGGER person_change_trigger;
drop sequence person_sequence;

drop table person;

SELECT * FROM ALL_DEPENDENCIES WHERE TYPE = 'TRIGGER' and name like '%insert%';

create table Employee_table(
    employeeId number(6) not null primary key,
    firstName varchar2(30),
    lastName varchar2(30),
    department_id number(4),
    managerId number(6),
    jobTitle varchar2(30),
    email varchar2(50),
    salary decimal,
    constraint employee_dept_fk foreign key(department_id) references department (department_id)
);

commit;

create table employee(
    employeeId number(6) not null primary key,
    firstName varchar2(30),
    lastName varchar2(30),
    department_id number(4),
    managerId number(6),
    jobTitle varchar2(30),
    email varchar2(50),
    constraint emp_fk foreign key(department_id) references department (department_id)
);

create sequence emp_sequence increment by 1 start with 200001 order;

create or replace trigger emp_trigger_before_insert
before insert on employee
for each row
begin
    select emp_sequence.nextval into :new.employeeId from dual;
end;

insert into employee(firstName, lastName, department_id, managerId, jobTitle, email)
values('Divya','Selvarajan',101,null,'HR Head', 'divya@abc.com');

insert all
    into employee(firstName, lastName, department_id, managerId, jobTitle, email)
        values('Kavinaya','Balaji',101,200001,'HR Executive', 'Kavi@abc.com')
    into employee(firstName, lastName, department_id, managerId, jobTitle, email)
        values('Balaji','Jayakumar',103,null,'Finance Head', 'bala@abc.com')
    into department
        values(106, 'Network')
    select * from dual;

ALTER table employee
    add salary decimal(6,2);
select * from employee;
create table department (
    department_id number(4)not null primary key,
    departmentName VARCHAR(20)
);

create table Address(
    addressLine varchar2(50),
    city varchar2(50),
    state varchar2(50),
    country varchar2(50),
    zipCode number(10)
);

insert into department values('101','HR');
insert into department values('102','Finance');
insert into department values('103','Admin');
insert into department values('104','Testing');
insert into department values('105','Development');

procedure update_salary 
as
begin
    update employee set salary = 1000 
    where department_id in 
    (select department_id from department where departmentName = 'HR');
end;

update employee set salary = 1700 
    where department_id = 103;
    
function calculate_max_salary return decimal as
sal employee.salary%type;
begin
    select max(salary) into sal from employee group by department_id;
    return sal;
end;

Create or replace package emp_eval as 
procedure eval_dept(dept_id IN number);
function calc_score(eval_id IN number, performance_id IN number) return Number;
TYPE sal_info IS RECORD
(j_id jobs.job_id%TYPE,
sal_min jobs.min_salary%TYPE, 
sal_max jobs.max_salary%TYPE, 
sal emoloyee.salary%TYPE,
sal_raise number(3,3));

end emp_eval;



