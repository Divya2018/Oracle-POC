
set SERVEROUTPUT ON;
declare
cursor emp_cursor IS select * from employee;
emp_record employee%ROWTYPE;
begin
open emp_cursor;
loop
fetch emp_cursor into emp_record;
exit when emp_cursor%notfound;
DBMS_OUTPUT.PUT_LINE(emp_record.lastName || ' ' || emp_record.firstname);
end loop;
DBMS_OUTPUT.PUT_LINE(emp_cursor%ROWCOUNT);
close emp_cursor;
end;

declare
cursor emp1_cursor IS select * from employee;
begin
for emp_record IN emp1_cursor
loop
DBMS_OUTPUT.PUT_LINE(emp_record.employeeId || ' ' || emp_record.firstname || ' ' || emp_record.email);
end loop;
end;