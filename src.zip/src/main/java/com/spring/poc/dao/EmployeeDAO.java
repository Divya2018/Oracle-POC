package com.spring.poc.dao;

import java.util.List;

import com.spring.poc.model.Employee;

public interface EmployeeDAO {
	public void addEmployee(Employee employee);
	public void updateEmployee(Employee employee);
	public void removeEmployee(int id);
	public List<Employee> listEmployees();
	public Employee getEmployeeById(int id);
}
