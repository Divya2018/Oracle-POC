package com.spring.poc.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.poc.dao.EmployeeDAO;
import com.spring.poc.model.Employee;

@Service
public class EmployeeServiceImple implements EmployeeService {
	
	private EmployeeDAO employeeDAO;
	
	public void setEmployeeDAO(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}
	@Transactional
	public void addEmployee(Employee employee) {
		this.employeeDAO.addEmployee(employee);
		
	}
	@Transactional
	public void updateEmployee(Employee employee) {
		this.employeeDAO.updateEmployee(employee);
		
	}
	@Transactional
	public void removeEmployee(int id) {
		this.employeeDAO.removeEmployee(id);
		
	}
	@Transactional
	public List<Employee> listEmployees() {
		return this.employeeDAO.listEmployees();
	}
	@Transactional
	public Employee getEmployeeById(int id) {
		return this.employeeDAO.getEmployeeById(id);
	}

}
